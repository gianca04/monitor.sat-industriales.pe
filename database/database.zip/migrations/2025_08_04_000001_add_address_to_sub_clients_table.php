<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('sub_clients', function (Blueprint $table) {
            $table->string('address')->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('sub_clients', function (Blueprint $table) {
            $table->dropColumn('address');
        });
    }
};
