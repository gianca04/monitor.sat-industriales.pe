<?php

namespace App\Services;

use App\DTOs\DeliveryExportData;
use App\Models\Delivery;
use Illuminate\Support\Facades\Log;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Worksheet\Drawing;

class ExportDeliveryEppService
{
    /**
     * Ruta relativa o absoluta de la plantilla excel
     */
    protected string $templatePath;

    public function __construct()
    {
        $resourcePath = resource_path('format/F-SST-SAT-016_FORMATO_DE_ENTREGA_DE_EPPS_NUEVO.xlsx');
        $basePath = base_path('format/F-SST-SAT-016_FORMATO_DE_ENTREGA_DE_EPPS_NUEVO.xlsx');

        Log::info('ExportDeliveryEppService: Iniciando verificación de plantilla.', [
            'resource_path' => $resourcePath,
            'resource_exists' => file_exists($resourcePath),
            'base_path' => $basePath,
            'base_exists' => file_exists($basePath),
        ]);

        if (file_exists($resourcePath)) {
            $this->templatePath = $resourcePath;
            Log::info('ExportDeliveryEppService: Plantilla seleccionada en resources.', ['path' => $resourcePath]);
        } elseif (file_exists($basePath)) {
            $this->templatePath = $basePath;
            Log::info('ExportDeliveryEppService: Plantilla seleccionada en base_path.', ['path' => $basePath]);
        } else {
            Log::error('ExportDeliveryEppService: Plantilla no encontrada en ninguna de las rutas.', [
                'resource_path' => $resourcePath,
                'base_path' => $basePath,
            ]);
            throw new \Exception("Plantilla Excel no encontrada. Buscado en: {$resourcePath} y {$basePath}");
        }
    }

    /**
     * Exporta los datos de una entrega usando la plantilla Excel
     *
     * @return string Ruta del archivo generado
     */
    public function export(DeliveryExportData $data): string
    {
        $spreadsheet = IOFactory::load($this->templatePath);
        $sheet = $spreadsheet->getActiveSheet();

        // 1. Rellenar datos del cabezal del trabajador
        $sheet->setCellValue('A14', $data->employeeName);
        $sheet->setCellValue('N14', $data->employeeDni);
        $sheet->setCellValue('O14', $data->employeeArea);
        $sheet->setCellValue('Q1', $data->documentCode);
        $sheet->setCellValue('Q2', $data->exportDate);

        // Rellenar datos del creador / responsable del registro
        $sheet->setCellValue('C35', $data->creatorFirstName);
        $sheet->setCellValue('A36', $data->creatorLastName);
        $sheet->setCellValue('C37', $data->creatorPosition);
        $sheet->setCellValue('C38', $data->creatorFullDate);

        // 2. Rellenar los ítems
        $startRow = 18;
        $maxPredefinedRows = 13; // filas 18 a 30 inclusive en la plantilla

        $totalItems = count($data->items);

        for ($i = 0; $i < $totalItems; $i++) {
            $currentRow = $startRow + $i;

            // Si superamos las 13 filas predefinidas en la plantilla, insertamos una nueva fila
            if ($i >= $maxPredefinedRows) {
                $sheet->insertNewRowBefore($currentRow, 1);

                // Replicar las celdas fusionadas de la fila modelo anterior
                $sheet->mergeCells("E{$currentRow}:I{$currentRow}");
                $sheet->mergeCells("J{$currentRow}:K{$currentRow}");
                $sheet->mergeCells("L{$currentRow}:M{$currentRow}");
                $sheet->mergeCells("P{$currentRow}:Q{$currentRow}");

                // Copiar estilos de bordes y formatos de la fila anterior
                $this->copyRowStyles($sheet, $currentRow - 1, $currentRow);
            }

            $item = $data->items[$i];

            $sheet->setCellValue("A{$currentRow}", $i + 1);
            $sheet->setCellValue("B{$currentRow}", 'X');
            $sheet->setCellValue("C{$currentRow}", ' ');
            $sheet->setCellValue("D{$currentRow}", $item->sku);
            $sheet->setCellValue("E{$currentRow}", $item->type);
            $sheet->setCellValue("J{$currentRow}", $item->quantity);
            $sheet->setCellValue("L{$currentRow}", $item->deliveredAt ? $item->deliveredAt->format('d/m/Y') : '');
            $sheet->setCellValue("N{$currentRow}", ' ');
            $sheet->setCellValue("O{$currentRow}", $item->notes);
            $sheet->setCellValue("P{$currentRow}", ' ');

            if (! empty($item->signature)) {
                $sheet->getRowDimension($currentRow)->setRowHeight(35);
                $this->insertSignatureImage($sheet, $item->signature, "P{$currentRow}");
            }
        }

        // Crear directorio temporal si no existe
        $tempDir = storage_path('app/public/exports');
        if (! file_exists($tempDir)) {
            mkdir($tempDir, 0755, true);
        }

        $filename = 'entrega_epp_'.time().'_'.uniqid().'.xlsx';
        $tempPath = $tempDir.'/'.$filename;

        $writer = IOFactory::createWriter($spreadsheet, 'Xlsx');
        $writer->save($tempPath);

        return $tempPath;
    }

    /**
     * Ejecuta la exportación directamente desde el modelo Delivery
     *
     * @return string Ruta del archivo generado
     */
    public function exportFromModel(Delivery $delivery): string
    {
        $dto = DeliveryExportData::fromModel($delivery);

        return $this->export($dto);
    }

    /**
     * Copia los estilos de celda de una fila a otra
     *
     * @param  \PhpOffice\PhpSpreadsheet\Worksheet\Worksheet  $sheet
     */
    private function copyRowStyles($sheet, int $fromRow, int $toRow): void
    {
        foreach (['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q'] as $col) {
            $fromCell = $sheet->getCell($col.$fromRow);
            $toCell = $sheet->getCell($col.$toRow);
            $toCell->setXfIndex($fromCell->getXfIndex());
        }
    }

    /**
     * Inserta la imagen de la firma en la celda correspondiente
     *
     * @param  \PhpOffice\PhpSpreadsheet\Worksheet\Worksheet  $sheet
     */
    private function insertSignatureImage($sheet, string $signatureData, string $cellCoordinates): void
    {
        if (empty($signatureData)) {
            return;
        }

        $tempImgPath = null;

        if (preg_match('/^data:image\/(\w+);base64,/', $signatureData, $type)) {
            $data = substr($signatureData, strpos($signatureData, ',') + 1);
            $decodedData = base64_decode($data);
            if ($decodedData === false) {
                return;
            }
            $ext = strtolower($type[1] ?? 'png');
            $tempImgPath = sys_get_temp_dir().'/sig_'.uniqid().'.'.$ext;
            file_put_contents($tempImgPath, $decodedData);
        } elseif (file_exists($signatureData)) {
            $tempImgPath = $signatureData;
        }

        if ($tempImgPath && file_exists($tempImgPath)) {
            $drawing = new Drawing;
            $drawing->setName('Firma');
            $drawing->setDescription('Firma de conformidad');
            $drawing->setPath($tempImgPath);
            $drawing->setCoordinates($cellCoordinates);
            $drawing->setHeight(30);
            $drawing->setOffsetX(10);
            $drawing->setOffsetY(2);
            $drawing->setWorksheet($sheet);
        }
    }
}
