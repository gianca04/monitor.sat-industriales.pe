<?php

namespace App\Filament\Resources\EppResource\RelationManagers;

use Filament\Forms;
use Filament\Forms\Form;
use Filament\Notifications\Notification;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Tables;
use Filament\Tables\Table;

class StockMovementsRelationManager extends RelationManager
{
    protected static string $relationship = 'stockMovements';

    protected static ?string $modelLabel = 'Movimiento';

    protected static ?string $pluralModelLabel = 'Movimientos de Stock';

    protected static ?string $title = 'Movimientos de Stock';

    public function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\DateTimePicker::make('created_at')
                    ->label('Fecha')
                    ->disabled(),
                Forms\Components\TextInput::make('eppVariant.sku')
                    ->label('SKU')
                    ->disabled(),
                Forms\Components\TextInput::make('type')
                    ->label('Tipo')
                    ->formatStateUsing(fn (string $state): string => match ($state) {
                        'input' => 'Ingreso',
                        'transfer_in' => 'Ingreso por traslado',
                        'loss' => 'Merma / Ajuste',
                        'adjustment_out' => 'Merma / Ajuste',
                        'transfer_out' => 'Salida por traslado',
                        'output' => 'Salida',
                        'dispatch' => 'Despacho',
                        default => ucfirst($state),
                    })
                    ->disabled(),
                Forms\Components\TextInput::make('warehouse.name')
                    ->label('Almacén')
                    ->disabled(),
                Forms\Components\TextInput::make('warehouseLocation.code')
                    ->label('Ubicación')
                    ->disabled(),
                Forms\Components\TextInput::make('quantity')
                    ->label('Cantidad')
                    ->numeric()
                    ->disabled(),
                Forms\Components\TextInput::make('unit_cost')
                    ->label('Costo Unitario')
                    ->numeric()
                    ->prefix('S/')
                    ->disabled(),
                Forms\Components\TextInput::make('user.name')
                    ->label('Registrado por')
                    ->formatStateUsing(fn ($record) => $record?->user?->employee ? "{$record->user->employee->first_name} {$record->user->employee->last_name}" : ($record?->user?->name ?? 'Sistema'))
                    ->disabled(),
                Forms\Components\Textarea::make('description')
                    ->label('Descripción')
                    ->columnSpanFull()
                    ->disabled(),
            ]);
    }

    public function table(Table $table): Table
    {
        return $table
            ->recordTitleAttribute('id')
            ->columns([
                Tables\Columns\TextColumn::make('created_at')
                    ->label('Fecha')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(),
                Tables\Columns\TextColumn::make('eppVariant.sku')
                    ->label('SKU')
                    ->sortable()
                    ->searchable()
                    ->toggleable(),
                Tables\Columns\TextColumn::make('type')
                    ->label('Tipo')
                    ->badge()
                    ->color(fn (string $state): string => match ($state) {
                        'input' => 'success',
                        'transfer_in' => 'success',
                        'loss' => 'danger',
                        'adjustment_out' => 'danger',
                        'transfer_out' => 'danger',
                        'output' => 'warning',
                        'dispatch' => 'warning',
                        default => 'gray',
                    })
                    ->formatStateUsing(fn (string $state): string => match ($state) {
                        'input' => 'Ingreso',
                        'transfer_in' => 'Ingreso por traslado',
                        'loss' => 'Merma / Ajuste',
                        'adjustment_out' => 'Merma / Ajuste',
                        'transfer_out' => 'Salida por traslado',
                        'output' => 'Salida',
                        'dispatch' => 'Despacho',
                        default => ucfirst($state),
                    })
                    ->toggleable(),
                Tables\Columns\TextColumn::make('warehouse.name')
                    ->label('Almacén')
                    ->sortable()
                    ->searchable()
                    ->toggleable(),
                Tables\Columns\TextColumn::make('warehouseLocation.code')
                    ->label('Ubicación')
                    ->sortable()
                    ->searchable()
                    ->toggleable(),
                Tables\Columns\TextColumn::make('quantity')
                    ->label('Cantidad')
                    ->numeric()
                    ->sortable()
                    ->toggleable(),
                Tables\Columns\TextColumn::make('unit_cost')
                    ->label('Costo Unit.')
                    ->money('PEN')
                    ->sortable()
                    ->toggleable(),
                Tables\Columns\TextColumn::make('user.employee')
                    ->label('Registrado por')
                    ->formatStateUsing(fn ($record) => $record->user?->employee ? "{$record->user->employee->first_name} {$record->user->employee->last_name}" : ($record->user?->name ?? 'Sistema'))
                    ->sortable()
                    ->toggleable(),
                Tables\Columns\TextColumn::make('description')
                    ->label('Descripción')
                    ->limit(50)
                    ->toggledHiddenByDefault(true)
                    ->searchable(),
            ])
            ->defaultSort('id', 'desc')
            ->filters([
                //
            ])
            ->headerActions([
                Tables\Actions\Action::make('ingreso')
                    ->label('Ingreso de Stock')
                    ->color('success')
                    ->icon('heroicon-o-plus-circle')
                    ->form([
                        Forms\Components\Select::make('epp_variant_id')
                            ->label('Variante (SKU)')
                            ->options(function (RelationManager $livewire) {
                                return \App\Models\EppVariant::where('epp_id', $livewire->getOwnerRecord()->id)
                                    ->pluck('sku', 'id');
                            })
                            ->required()
                            ->searchable()
                            ->preload()
                            ->live()
                            ->afterStateUpdated(function (Forms\Set $set, Forms\Get $get) {
                                $variantId = $get('epp_variant_id');
                                $locationId = $get('warehouse_location_id');
                                if ($variantId && $locationId) {
                                    $stock = app(\App\Services\InventoryService::class)->getStock($variantId, $locationId);
                                    $set('current_stock', $stock ? $stock->current_stock : 0);
                                } else {
                                    $set('current_stock', 0);
                                }
                            }),
                        Forms\Components\Select::make('warehouse_id')
                            ->label('Almacén')
                            ->options(\App\Models\Warehouse::all()->pluck('name', 'id'))
                            ->required()
                            ->preload()
                            ->searchable()
                            ->live(),
                        Forms\Components\Select::make('warehouse_location_id')
                            ->label('Ubicación de Almacén')
                            ->options(function (Forms\Get $get) {
                                $warehouseId = $get('warehouse_id');
                                if (! $warehouseId) {
                                    return [];
                                }

                                return \App\Models\WarehouseLocation::where('warehouse_id', $warehouseId)
                                    ->pluck('code', 'id');
                            })
                            ->required()
                            ->searchable()
                            ->preload()
                            ->disabled(fn (Forms\Get $get): bool => ! $get('warehouse_id'))
                            ->live()
                            ->afterStateUpdated(function (Forms\Set $set, Forms\Get $get) {
                                $variantId = $get('epp_variant_id');
                                $locationId = $get('warehouse_location_id');
                                if ($variantId && $locationId) {
                                    $stock = app(\App\Services\InventoryService::class)->getStock($variantId, $locationId);
                                    $set('current_stock', $stock ? $stock->current_stock : 0);
                                } else {
                                    $set('current_stock', 0);
                                }
                            }),
                        Forms\Components\TextInput::make('current_stock')
                            ->label('Stock Actual en Ubicación')
                            ->numeric()
                            ->disabled()
                            ->dehydrated(false)
                            ->default(0),
                        Forms\Components\TextInput::make('quantity')
                            ->label('Cantidad')
                            ->required()
                            ->numeric()
                            ->minValue(1),
                        Forms\Components\TextInput::make('unit_cost')
                            ->label('Costo Unitario (S/)')
                            ->numeric()
                            ->prefix('S/')
                            ->minValue(0),
                        Forms\Components\Textarea::make('description')
                            ->label('Descripción')
                            ->required(),
                    ])
                    ->action(function (array $data, \Livewire\Component $livewire) {
                        $action = app(\App\Actions\BulkStockEntryAction::class);
                        try {
                            $action->execute([
                                [
                                    'epp_variant_id' => $data['epp_variant_id'],
                                    'warehouse_location_id' => $data['warehouse_location_id'],
                                    'quantity' => $data['quantity'],
                                    'unit_cost' => $data['unit_cost'] ?? null,
                                    'description' => $data['description'],
                                ],
                            ]);
                            Notification::make()
                                ->title('Ingreso registrado con éxito')
                                ->success()
                                ->send();

                            $livewire->redirect(\App\Filament\Resources\EppResource::getUrl('index'));
                        } catch (\Exception $e) {
                            Notification::make()
                                ->title('Error al registrar ingreso')
                                ->body($e->getMessage())
                                ->danger()
                                ->send();
                        }
                    }),

                Tables\Actions\Action::make('merma')
                    ->label('Registrar Merma')
                    ->color('danger')
                    ->icon('heroicon-o-minus-circle')
                    ->form([
                        Forms\Components\Select::make('epp_variant_id')
                            ->label('Variante (SKU)')
                            ->options(function (RelationManager $livewire) {
                                return \App\Models\EppVariant::where('epp_id', $livewire->getOwnerRecord()->id)
                                    ->pluck('sku', 'id');
                            })
                            ->required()
                            ->searchable()
                            ->preload()
                            ->live()
                            ->afterStateUpdated(function (Forms\Set $set, Forms\Get $get) {
                                $variantId = $get('epp_variant_id');
                                $locationId = $get('warehouse_location_id');
                                if ($variantId && $locationId) {
                                    $stock = app(\App\Services\InventoryService::class)->getStock($variantId, $locationId);
                                    $set('current_stock', $stock ? $stock->current_stock : 0);
                                } else {
                                    $set('current_stock', 0);
                                }
                            }),
                        Forms\Components\Select::make('warehouse_id')
                            ->label('Almacén (Origen)')
                            ->options(function (Forms\Get $get) {
                                if (! $get('epp_variant_id')) {
                                    return [];
                                }

                                return \App\Models\Stock::with('warehouse')
                                    ->where('epp_variant_id', $get('epp_variant_id'))
                                    ->where('current_stock', '>', 0)
                                    ->get()
                                    ->pluck('warehouse.name', 'warehouse_id');
                            })
                            ->required()
                            ->searchable()
                            ->preload()
                            ->live(),
                        Forms\Components\Select::make('warehouse_location_id')
                            ->label('Ubicación de Almacén (Origen)')
                            ->options(function (Forms\Get $get) {
                                if (! $get('epp_variant_id') || ! $get('warehouse_id')) {
                                    return [];
                                }

                                return \App\Models\Stock::with('warehouseLocation')
                                    ->where('epp_variant_id', $get('epp_variant_id'))
                                    ->where('warehouse_id', $get('warehouse_id'))
                                    ->where('current_stock', '>', 0)
                                    ->get()
                                    ->pluck('warehouseLocation.code', 'warehouse_location_id');
                            })
                            ->required()
                            ->searchable()
                            ->preload()
                            ->disabled(fn (Forms\Get $get): bool => ! $get('warehouse_id'))
                            ->live()
                            ->afterStateUpdated(function (Forms\Set $set, Forms\Get $get) {
                                $variantId = $get('epp_variant_id');
                                $locationId = $get('warehouse_location_id');
                                if ($variantId && $locationId) {
                                    $stock = app(\App\Services\InventoryService::class)->getStock($variantId, $locationId);
                                    $set('current_stock', $stock ? $stock->current_stock : 0);
                                } else {
                                    $set('current_stock', 0);
                                }
                            }),
                        Forms\Components\TextInput::make('current_stock')
                            ->label('Stock Actual en Ubicación')
                            ->numeric()
                            ->disabled()
                            ->dehydrated(false)
                            ->default(0),
                        Forms\Components\TextInput::make('quantity')
                            ->label('Cantidad')
                            ->required()
                            ->numeric()
                            ->minValue(1),
                        Forms\Components\Textarea::make('description')
                            ->label('Descripción (Motivo de merma)')
                            ->required(),
                    ])
                    ->action(function (array $data) {
                        $action = app(\App\Actions\AdjustStockAction::class);
                        try {
                            $action->execute(
                                $data['epp_variant_id'],
                                $data['warehouse_location_id'],
                                $data['quantity'],
                                'loss',
                                $data['description']
                            );
                            Notification::make()
                                ->title('Merma registrada con éxito')
                                ->success()
                                ->send();
                        } catch (\Exception $e) {
                            Notification::make()
                                ->title('Error al registrar merma')
                                ->body($e->getMessage())
                                ->danger()
                                ->send();
                        }
                    }),

                Tables\Actions\Action::make('traslado')
                    ->label('Trasladar Stock')
                    ->color('warning')
                    ->icon('heroicon-o-arrows-right-left')
                    ->form([
                        Forms\Components\Select::make('epp_variant_id')
                            ->label('Variante (SKU)')
                            ->options(function (RelationManager $livewire) {
                                return \App\Models\EppVariant::where('epp_id', $livewire->getOwnerRecord()->id)
                                    ->pluck('sku', 'id');
                            })
                            ->required()
                            ->searchable()
                            ->preload()
                            ->live()
                            ->afterStateUpdated(function (Forms\Set $set, Forms\Get $get) {
                                $variantId = $get('epp_variant_id');
                                $sourceLocId = $get('source_location_id');
                                $targetLocId = $get('target_location_id');

                                if ($variantId && $sourceLocId) {
                                    $stock = app(\App\Services\InventoryService::class)->getStock($variantId, $sourceLocId);
                                    $set('source_stock', $stock ? $stock->current_stock : 0);
                                } else {
                                    $set('source_stock', 0);
                                }

                                if ($variantId && $targetLocId) {
                                    $stock = app(\App\Services\InventoryService::class)->getStock($variantId, $targetLocId);
                                    $set('target_stock', $stock ? $stock->current_stock : 0);
                                } else {
                                    $set('target_stock', 0);
                                }
                            }),
                        Forms\Components\Select::make('source_warehouse_id')
                            ->label('Almacén (Origen)')
                            ->options(function (Forms\Get $get) {
                                if (! $get('epp_variant_id')) {
                                    return [];
                                }

                                return \App\Models\Stock::with('warehouse')
                                    ->where('epp_variant_id', $get('epp_variant_id'))
                                    ->where('current_stock', '>', 0)
                                    ->get()
                                    ->pluck('warehouse.name', 'warehouse_id');
                            })
                            ->required()
                            ->searchable()
                            ->preload()
                            ->live(),
                        Forms\Components\Select::make('source_location_id')
                            ->label('Ubicación de Origen')
                            ->options(function (Forms\Get $get) {
                                if (! $get('epp_variant_id') || ! $get('source_warehouse_id')) {
                                    return [];
                                }

                                return \App\Models\Stock::with('warehouseLocation')
                                    ->where('epp_variant_id', $get('epp_variant_id'))
                                    ->where('warehouse_id', $get('source_warehouse_id'))
                                    ->where('current_stock', '>', 0)
                                    ->get()
                                    ->pluck('warehouseLocation.code', 'warehouse_location_id');
                            })
                            ->required()
                            ->searchable()
                            ->preload()
                            ->disabled(fn (Forms\Get $get): bool => ! $get('source_warehouse_id'))
                            ->live()
                            ->afterStateUpdated(function (Forms\Set $set, Forms\Get $get) {
                                $variantId = $get('epp_variant_id');
                                $locationId = $get('source_location_id');
                                if ($variantId && $locationId) {
                                    $stock = app(\App\Services\InventoryService::class)->getStock($variantId, $locationId);
                                    $set('source_stock', $stock ? $stock->current_stock : 0);
                                } else {
                                    $set('source_stock', 0);
                                }
                            }),
                        Forms\Components\TextInput::make('source_stock')
                            ->label('Stock Disponible en Origen')
                            ->numeric()
                            ->disabled()
                            ->dehydrated(false)
                            ->default(0),
                        Forms\Components\Select::make('target_warehouse_id')
                            ->label('Almacén (Destino)')
                            ->options(\App\Models\Warehouse::all()->pluck('name', 'id'))
                            ->required()
                            ->searchable()
                            ->preload()
                            ->live(),
                        Forms\Components\Select::make('target_location_id')
                            ->label('Ubicación de Destino')
                            ->options(function (Forms\Get $get) {
                                $warehouseId = $get('target_warehouse_id');
                                if (! $warehouseId) {
                                    return [];
                                }

                                return \App\Models\WarehouseLocation::where('warehouse_id', $warehouseId)
                                    ->pluck('code', 'id');
                            })
                            ->required()
                            ->searchable()
                            ->preload()
                            ->disabled(fn (Forms\Get $get): bool => ! $get('target_warehouse_id'))
                            ->different('source_location_id')
                            ->live()
                            ->afterStateUpdated(function (Forms\Set $set, Forms\Get $get) {
                                $variantId = $get('epp_variant_id');
                                $locationId = $get('target_location_id');
                                if ($variantId && $locationId) {
                                    $stock = app(\App\Services\InventoryService::class)->getStock($variantId, $locationId);
                                    $set('target_stock', $stock ? $stock->current_stock : 0);
                                } else {
                                    $set('target_stock', 0);
                                }
                            }),
                        Forms\Components\TextInput::make('target_stock')
                            ->label('Stock Actual en Destino')
                            ->numeric()
                            ->disabled()
                            ->dehydrated(false)
                            ->default(0),
                        Forms\Components\TextInput::make('quantity')
                            ->label('Cantidad')
                            ->required()
                            ->numeric()
                            ->minValue(1),
                        Forms\Components\Textarea::make('description')
                            ->label('Descripción'),
                    ])
                    ->action(function (array $data) {
                        $action = app(\App\Actions\TransferStockAction::class);
                        try {
                            $action->execute(
                                $data['epp_variant_id'],
                                $data['source_location_id'],
                                $data['target_location_id'],
                                $data['quantity'],
                                $data['description']
                            );
                            Notification::make()
                                ->title('Traslado registrado con éxito')
                                ->success()
                                ->send();
                        } catch (\Exception $e) {
                            Notification::make()
                                ->title('Error al registrar traslado')
                                ->body($e->getMessage())
                                ->danger()
                                ->send();
                        }
                    }),
            ])
            ->actions([
                Tables\Actions\ViewAction::make(),
            ])
            ->recordAction(Tables\Actions\ViewAction::class)
            ->bulkActions([
                // Movimientos inmutables
            ]);
    }
}
